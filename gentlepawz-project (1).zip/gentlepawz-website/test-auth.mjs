import 'dotenv/config';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(process.env.VITE_SUPABASE_URL, process.env.VITE_SUPABASE_ANON_KEY);

// Test 1: Try to fetch public.users without auth (should return empty due to RLS)
console.log('\n=== Test 1: Unauthenticated query ===');
const { data: anonData, error: anonError } = await supabase.from('users').select('id,email,role').limit(3);
console.log('Result:', anonError ? 'ERROR: ' + anonError.message : JSON.stringify(anonData));

// Test 2: Sign in as emily and fetch her profile
console.log('\n=== Test 2: Login as emily@gentlepawz.ca ===');
const { data: loginData, error: loginError } = await supabase.auth.signInWithPassword({
  email: 'emily@gentlepawz.ca',
  password: 'GentlePawz2024!'
});
if (loginError) {
  console.log('Login failed:', loginError.message);
} else {
  console.log('Login OK, uid:', loginData.user.id);
  
  // Fetch own profile
  const { data: profile, error: profileError } = await supabase
    .from('users')
    .select('id, email, role, full_name')
    .eq('id', loginData.user.id)
    .maybeSingle();
  
  if (profileError) {
    console.log('Profile fetch ERROR:', JSON.stringify(profileError));
  } else {
    console.log('Profile:', JSON.stringify(profile));
  }
  
  // Also test .single() vs .maybeSingle()
  const { data: profile2, error: profileError2 } = await supabase
    .from('users')
    .select('role')
    .eq('id', loginData.user.id)
    .single();
  console.log('Single result:', profileError2 ? 'ERROR: ' + profileError2.message : JSON.stringify(profile2));
}

// Test 3: Sign in as johnsnow
console.log('\n=== Test 3: Login as johnsnow@gmail.com ===');
const { data: johnData, error: johnError } = await supabase.auth.signInWithPassword({
  email: 'johnsnow@gmail.com',
  password: 'GentlePawz2024!'
});
if (johnError) {
  console.log('Login failed:', johnError.message);
} else {
  console.log('Login OK, uid:', johnData.user.id);
  const { data: johnProfile, error: johnProfileError } = await supabase
    .from('users')
    .select('id, email, role')
    .eq('id', johnData.user.id)
    .maybeSingle();
  console.log('Profile:', johnProfileError ? 'ERROR: ' + johnProfileError.message : JSON.stringify(johnProfile));
}
