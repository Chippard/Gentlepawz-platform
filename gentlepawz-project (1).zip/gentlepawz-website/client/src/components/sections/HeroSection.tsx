import { Button } from "@/components/ui/button";
import { ArrowRight, Shield, Heart, Star, PawPrint } from "lucide-react";
import { useEffect, useState } from "react";

const LOGO_URL = "/manus-storage/gentle_pawz_logo_8cb535b8.png";
const DOG_HERO_URL = "/manus-storage/dog_hero_2189f2a1.jpg";
const DOG_PORTRAIT_URL = "/manus-storage/dog_portrait_8e83fb33.jpg";

export function HeroSection() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    // Trigger entrance animations after mount
    const t = setTimeout(() => setVisible(true), 80);
    return () => clearTimeout(t);
  }, []);

  return (
    <section className="relative min-h-[100dvh] flex items-center overflow-hidden bg-[#0a2a2a]">
      {/* Full-bleed background photo with overlay */}
      <div className="absolute inset-0">
        <img
          src={DOG_HERO_URL}
          alt="Happy golden retriever"
          className="w-full h-full object-cover object-center opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-[#0a2a2a] via-[#0d3535]/80 to-[#0a2a2a]/90" />
      </div>

      {/* Animated floating paw prints */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[
          { top: "10%", left: "5%", delay: "0s", size: 20, opacity: 0.12 },
          { top: "25%", left: "88%", delay: "1.2s", size: 14, opacity: 0.10 },
          { top: "60%", left: "3%", delay: "2.1s", size: 18, opacity: 0.08 },
          { top: "75%", left: "92%", delay: "0.7s", size: 12, opacity: 0.10 },
          { top: "45%", left: "50%", delay: "1.8s", size: 10, opacity: 0.06 },
          { top: "85%", left: "20%", delay: "3s", size: 16, opacity: 0.09 },
        ].map((p, i) => (
          <PawPrint
            key={i}
            className="absolute text-[#2dd4bf] animate-[float_6s_ease-in-out_infinite]"
            style={{
              top: p.top,
              left: p.left,
              width: p.size,
              height: p.size,
              opacity: p.opacity,
              animationDelay: p.delay,
            }}
          />
        ))}
      </div>

      {/* Glowing orbs */}
      <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-[#2dd4bf]/8 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 left-1/4 w-80 h-80 bg-[#1e7a6e]/15 rounded-full blur-3xl pointer-events-none" />

      <div className="container relative z-10 pt-28 pb-20">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">

          {/* ── Left content ── */}
          <div
            className="space-y-8"
            style={{
              opacity: visible ? 1 : 0,
              transform: visible ? "translateY(0)" : "translateY(32px)",
              transition: "opacity 0.8s ease, transform 0.8s ease",
            }}
          >
            {/* Logo */}
            <div className="flex items-center gap-4">
              <img
                src={LOGO_URL}
                alt="Gentle Pawz logo"
                className="w-20 h-20 drop-shadow-[0_0_20px_rgba(45,212,191,0.5)]"
                style={{
                  animation: "logoPulse 3s ease-in-out infinite",
                }}
              />
              <div>
                <p className="text-[#2dd4bf] text-xs font-semibold tracking-[0.2em] uppercase">
                  North Vancouver
                </p>
                <p className="text-white/60 text-sm">Boutique Dog Care</p>
              </div>
            </div>

            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#2dd4bf]/10 border border-[#2dd4bf]/30 backdrop-blur-sm">
              <span className="w-2 h-2 rounded-full bg-[#2dd4bf] animate-pulse" />
              <span className="text-sm font-medium text-[#2dd4bf]">
                Now Accepting Bookings — Max 2 Dogs at a Time
              </span>
            </div>

            {/* Headline */}
            <div className="space-y-4">
              <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight">
                Where Every Paw Gets{" "}
                <span
                  className="text-[#2dd4bf]"
                  style={{ textShadow: "0 0 40px rgba(45,212,191,0.4)" }}
                >
                  Personal
                </span>{" "}
                Care
              </h1>
              <p className="text-lg text-white/60 leading-relaxed max-w-lg">
                Boutique dog boarding and walking in North Vancouver. Your
                furry family member gets individual attention — never lost in
                a crowd.
              </p>
            </div>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                asChild
                size="lg"
                className="rounded-full px-8 text-base font-semibold bg-[#2dd4bf] hover:bg-[#22b8a5] text-[#0a2a2a] shadow-[0_0_30px_rgba(45,212,191,0.4)] hover:shadow-[0_0_40px_rgba(45,212,191,0.6)] transition-all duration-300"
              >
                <a href="/booking">
                  Book a Stay
                  <ArrowRight className="ml-2 w-4 h-4" />
                </a>
              </Button>
              <Button
                asChild
                variant="outline"
                size="lg"
                className="rounded-full px-8 text-base border-white/20 text-white hover:bg-white/10 bg-white/5 backdrop-blur-sm"
              >
                <a href="#services">Our Services</a>
              </Button>
            </div>

            {/* Trust indicators */}
            <div className="flex flex-wrap gap-6 pt-2">
              {[
                { icon: Shield, label: "Insured & Certified" },
                { icon: Heart, label: "Max 2 Dogs" },
                { icon: Star, label: "5-Star Rated" },
              ].map(({ icon: Icon, label }) => (
                <div
                  key={label}
                  className="flex items-center gap-2 text-sm text-white/50"
                >
                  <Icon className="w-4 h-4 text-[#2dd4bf]" />
                  <span>{label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* ── Right visual ── */}
          <div
            className="relative hidden lg:block"
            style={{
              opacity: visible ? 1 : 0,
              transform: visible ? "translateY(0)" : "translateY(40px)",
              transition: "opacity 1s ease 0.2s, transform 1s ease 0.2s",
            }}
          >
            <div className="relative w-full aspect-square max-w-lg mx-auto">
              {/* Glow ring */}
              <div className="absolute inset-4 rounded-full bg-[#2dd4bf]/10 blur-2xl" />

              {/* Main dog image */}
              <div
                className="absolute inset-8 rounded-3xl overflow-hidden border border-[#2dd4bf]/20 shadow-[0_0_60px_rgba(45,212,191,0.15)]"
                style={{ animation: "gentleFloat 6s ease-in-out infinite" }}
              >
                <img
                  src={DOG_PORTRAIT_URL}
                  alt="Happy golden retriever in a garden"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0a2a2a]/40 to-transparent" />
              </div>

              {/* Floating card — top right */}
              <div
                className="absolute top-2 right-0 bg-white/10 backdrop-blur-md rounded-2xl p-3.5 shadow-xl border border-white/20"
                style={{ animation: "gentleFloat 5s ease-in-out infinite 0.5s" }}
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-full bg-green-400/20 flex items-center justify-center">
                    <span className="text-green-400 text-sm">✓</span>
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-white">Booking Confirmed</p>
                    <p className="text-xs text-white/50">Emily responds in 24h</p>
                  </div>
                </div>
              </div>

              {/* Floating card — bottom left */}
              <div
                className="absolute bottom-6 -left-4 bg-white/10 backdrop-blur-md rounded-2xl p-3.5 shadow-xl border border-white/20"
                style={{ animation: "gentleFloat 7s ease-in-out infinite 1s" }}
              >
                <div className="flex items-center gap-3">
                  <img
                    src={LOGO_URL}
                    alt="logo"
                    className="w-8 h-8 rounded-full"
                  />
                  <div>
                    <p className="text-xs font-semibold text-white">Gentle Pawz</p>
                    <div className="flex gap-0.5 mt-0.5">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className="w-2.5 h-2.5 fill-yellow-400 text-yellow-400"
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg
          viewBox="0 0 1440 80"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full"
        >
          <path
            d="M0 40C240 80 480 0 720 40C960 80 1200 0 1440 40V80H0V40Z"
            className="fill-background"
          />
        </svg>
      </div>

      {/* Keyframe animations injected via style tag */}
      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-12px) rotate(5deg); }
        }
        @keyframes gentleFloat {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
        @keyframes logoPulse {
          0%, 100% { filter: drop-shadow(0 0 12px rgba(45,212,191,0.4)); }
          50% { filter: drop-shadow(0 0 28px rgba(45,212,191,0.8)); }
        }
      `}</style>
    </section>
  );
}
