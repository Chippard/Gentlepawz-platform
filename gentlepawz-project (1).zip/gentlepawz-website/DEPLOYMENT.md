# Gentlepawz — Vercel Deployment Guide

## Quick Start

### 1. Push to GitHub

```bash
# Clone or initialise the repo
git clone https://github.com/Chippard/Gentlepawz-platform.git
cd Gentlepawz-platform

# Copy the project files into the repo root
# (extract the zip, then copy gentlepawz-website/* here)
cp -r gentlepawz-website/* .

# Commit and push
git add .
git commit -m "feat: native booking form + new hero section with logo and dog imagery"
git push origin main
```

### 2. Configure Vercel

In **Vercel → Project Settings → General**:

| Setting | Value |
|---|---|
| Build Command | `pnpm build:client` |
| Output Directory | `dist/public` |
| Install Command | `pnpm install` |
| Framework Preset | Vite |

### 3. Add Environment Variables

In **Vercel → Project Settings → Environment Variables**, add:

| Name | Value |
|---|---|
| `VITE_SUPABASE_URL` | `https://viuxdmoxrxambomyjslq.supabase.co` |
| `VITE_SUPABASE_ANON_KEY` | *(your Supabase anon key — get from Supabase dashboard → Settings → API)* |

> **Note:** Only these two env vars are needed. All other vars (DATABASE_URL, JWT_SECRET, etc.) are only used by the Manus-hosted Express server and are not required for the Vercel static deployment.

### 4. Run the Supabase Migration

Before the site goes live, run **calendar-migration.sql** in your Supabase SQL editor:

1. Go to [Supabase Dashboard](https://supabase.com/dashboard) → your project → SQL Editor
2. Open `calendar-migration.sql` from this repo
3. Run it — this adds the `owner_name`, `email`, `pet_name` columns and the `contact_inquiries` table

### 5. Promote Admin Users

To give yourself admin access:

1. Sign up at `/signup` (choose any role — you'll upgrade it manually)
2. In Supabase Dashboard → Table Editor → `users` table
3. Find your row and set `role = 'admin'`

---

## What's Included

| Feature | Status |
|---|---|
| Hero section with Gentle Pawz logo + dog imagery | ✅ Live |
| Animated floating paw prints + entrance animations | ✅ Live |
| Native booking calendar (no external iframe) | ✅ Live |
| 2-dog daily limit enforcement | ✅ Live |
| Supabase Auth (sign-up, login, password reset) | ✅ Live |
| Role-based dashboards (customer / walker / admin) | ✅ Live |
| Contact form → Supabase `contact_inquiries` table | ✅ Live |
| Full RLS policies on all tables | ✅ Live |
| SPA routing via `vercel.json` rewrites | ✅ Live |

---

## Image CDN Note

The hero images are served from the Manus CDN (`/manus-storage/...`). These URLs are **permanent** and will continue to work after Vercel deployment — no action needed.

- Logo: `/manus-storage/gentle_pawz_logo_8cb535b8.png`
- Hero background: `/manus-storage/dog_hero_2189f2a1.jpg`
- Dog portrait: `/manus-storage/dog_portrait_8e83fb33.jpg`
