import { createClient } from '@supabase/supabase-js';

const url = process.env.VITE_SUPABASE_URL;
const key = process.env.VITE_SUPABASE_ANON_KEY;
const supabase = createClient(url, key);

// Discover bookings columns
const bookingCols = [
  'id', 'customer_id', 'walker_id', 'service_type', 'start_date', 'end_date',
  'status', 'price', 'notes', 'created_at', 'updated_at',
  'owner_name', 'email', 'pet_name', 'stay_dates', 'care_notes',
  'date', 'dates', 'dog_name', 'client_name', 'client_email',
  'confirmed', 'cancelled', 'pending', 'type', 'service', 'duration'
];

console.log('=== BOOKINGS TABLE COLUMNS ===');
const validBookingCols = [];
for (const col of bookingCols) {
  const { data, error } = await supabase.from('bookings').select(col).limit(0);
  if (error === null) {
    validBookingCols.push(col);
  }
}
console.log(validBookingCols.join(', '));

// Discover blocked_dates columns
const bdCols = [
  'id', 'date', 'reason', 'created_at', 'start_date', 'end_date',
  'blocked_date', 'type', 'updated_at', 'note', 'label'
];

console.log('\n=== BLOCKED_DATES TABLE COLUMNS ===');
const validBdCols = [];
for (const col of bdCols) {
  const { data, error } = await supabase.from('blocked_dates').select(col).limit(0);
  if (error === null) {
    validBdCols.push(col);
  }
}
console.log(validBdCols.join(', '));

// Try to fetch all bookings (even if empty) with valid columns
console.log('\n=== ALL BOOKINGS DATA ===');
const { data: allBookings, error: bookErr } = await supabase
  .from('bookings')
  .select(validBookingCols.join(','))
  .limit(10);
console.log('Error:', bookErr);
console.log('Data:', JSON.stringify(allBookings, null, 2));

// Try to fetch all blocked_dates
console.log('\n=== ALL BLOCKED_DATES DATA ===');
const { data: allBd, error: bdErr } = await supabase
  .from('blocked_dates')
  .select(validBdCols.join(','))
  .limit(10);
console.log('Error:', bdErr);
console.log('Data:', JSON.stringify(allBd, null, 2));
